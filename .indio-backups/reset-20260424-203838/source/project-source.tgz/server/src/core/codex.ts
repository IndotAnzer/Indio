import { spawn } from "node:child_process";
import { access, copyFile, mkdtemp, readFile, rm } from "node:fs/promises";
import { constants as fsConstants } from "node:fs";
import { join, resolve } from "node:path";
import { z } from "zod";
import type { AppConfig } from "../config.js";
import type { ContextBundle, Decision, PlaylistSeed, ProviderInfo, Track, TrackNarrationContext } from "../types.js";

function inferMoodFromHour(isoTime: string): string {
  const hour = new Date(isoTime).getHours();

  if (hour < 9) {
    return "morning";
  }

  if (hour < 18) {
    return "focus";
  }

  return "evening";
}

function getChinaTimeParts(isoTime: string): { clock: string; hour: number; weekday: string } {
  const parts = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Shanghai",
    hour: "2-digit",
    minute: "2-digit",
    weekday: "short",
    hourCycle: "h23"
  }).formatToParts(new Date(isoTime));
  const valueOf = (type: string) => parts.find((part) => part.type === type)?.value ?? "";
  const hour = Number(valueOf("hour"));

  return {
    clock: `${valueOf("hour")}:${valueOf("minute")}`,
    hour: Number.isFinite(hour) ? hour : new Date(isoTime).getHours(),
    weekday: valueOf("weekday")
  };
}

function inferRadioFrame(isoTime: string, mood: string): string {
  const { hour, weekday } = getChinaTimeParts(isoTime);
  const isWeekend = weekday === "周六" || weekday === "周日";

  if (isWeekend && hour >= 19 && hour < 24) {
    return "weekend-party";
  }

  if (hour >= 5 && hour < 10) {
    return "morning-city";
  }

  if (hour >= 11 && hour < 15) {
    return "noon-easy";
  }

  if (hour >= 22 || hour < 2 || mood === "evening") {
    return "late-night";
  }

  return mood === "focus" ? "workday-focus" : "music-companion";
}

function pickPlaylistQuery(playlists: PlaylistSeed[], mood: string): string {
  const matched = playlists.find((playlist) => playlist.mood === mood);

  if (matched && matched.tracks.length > 0) {
    return matched.tracks[0];
  }

  return mood;
}

function clip(value: string, maxLength: number): string {
  return value.length <= maxLength ? value : `${value.slice(0, maxLength)}...`;
}

function tail(value: string, maxLength: number): string {
  return value.length <= maxLength ? value : value.slice(-maxLength);
}

function compactLines(value: string | null | undefined): string | null {
  if (!value) {
    return null;
  }

  const text = value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .join(" ");

  return text ? clip(text, 240) : null;
}

function markdownHighlights(value: string, maxItems: number, maxLength: number): string[] {
  const bullets = value
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.startsWith("-"))
    .map((line) => line.replace(/^-+\s*/, ""))
    .filter(Boolean)
    .slice(0, maxItems)
    .map((line) => clip(line, maxLength));

  if (bullets.length > 0) {
    return bullets;
  }

  return value
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, maxItems)
    .map((line) => clip(line, maxLength));
}

function normalizeError(value: unknown): string {
  if (value instanceof Error) {
    return value.message;
  }

  return String(value);
}

function sameTrack(left: Track, right: Track): boolean {
  return (left.neteaseId ?? left.id) === (right.neteaseId ?? right.id);
}

const decisionOutputSchema = z.object({
  say: z.string().min(1),
  play: z
    .array(
      z
        .object({
          query: z.string().min(1).optional(),
          trackId: z.string().min(1).optional(),
          reason: z.string().min(1)
        })
        .refine((item) => Boolean(item.query || item.trackId), "query or trackId is required")
    )
    .max(3),
  reason: z.string().min(1),
  segue: z.string().min(1),
  mood: z.string().min(1),
  mode: z.enum(["narrated", "music-only"])
});

const narrationOutputSchema = z.object({
  narration: z.string().min(1).max(520)
});

const unwantedNarrationPatterns = [
  /\d{2,3}\s*(?:BPM|拍)/i,
  /(?:作词|填词|作曲|编曲|制作人|词曲|词是|词由|曲是|曲由|曲、编|一起写(?:出|成|下|的|来)|共同写)/,
  /(?:先)?安静接住|接住(?:你|你的|听众|心事|情绪|夜色|日常|这一段)?/,
  /把.{0,12}空气.{0,12}(?:拉|放|留|收|沉|柔)|空气.{0,8}(?:拉得|自动|收拢|变松|柔下来)/,
  /(?:同一条)?气流|纹理/,
  /(?:我们)?直接(?:把)?.{0,8}接上|直接接上|把.{0,8}接上/
];

function hasUnwantedNarrationStyle(value: string): boolean {
  return unwantedNarrationPatterns.some((pattern) => pattern.test(value));
}

export interface CodexIntent {
  moodHint?: string;
  quietMode?: boolean;
}

interface ProcessResult {
  code: number | null;
  stdout: string;
  stderr: string;
  timedOut: boolean;
  signal: NodeJS.Signals | null;
}

export class CodexAdapter {
  private statusCache:
    | {
        expiresAt: number;
        value: ProviderInfo;
      }
    | null = null;

  constructor(private readonly config: AppConfig) {}

  async decide(context: ContextBundle, intent: CodexIntent = {}): Promise<Decision> {
    if (this.config.codexMode !== "oauth-cli") {
      const provider = this.buildProvider({
        kind: "fallback",
        state: "disabled",
        authMode: "none",
        detail: `CODEX_MODE=${this.config.codexMode}, skipped OAuth Codex CLI.`,
        durationMs: 0
      });

      this.cacheStatus(provider);
      return this.fallbackDecision(context, intent, provider);
    }

    const loginStatus = await this.getLoginStatus(true);

    if (loginStatus.state !== "ready") {
      const provider = this.buildProvider({
        kind: "fallback",
        state: "fallback",
        authMode: loginStatus.authMode,
        detail: loginStatus.detail ?? "Local Codex CLI is not authenticated.",
        durationMs: 0
      });

      this.cacheStatus(provider);
      return this.fallbackDecision(context, intent, provider);
    }

    const startedAt = Date.now();

    try {
      const output = await this.runCodexExec(this.buildPrompt(context, intent), this.config.codexDecisionSchemaPath);
      const parsed = decisionOutputSchema.parse(JSON.parse(output));
      const provider = this.buildProvider({
        kind: "codex-cli",
        state: "ready",
        authMode: loginStatus.authMode,
        detail: "Used the local Codex CLI session authenticated with OAuth.",
        durationMs: Date.now() - startedAt
      });

      this.cacheStatus(provider);

      return {
        ...parsed,
        provider
      };
    } catch (error) {
      const provider = this.buildProvider({
        kind: "fallback",
        state: "fallback",
        authMode: loginStatus.authMode,
        detail: `Codex CLI failed, falling back locally. ${clip(normalizeError(error), 180)}`,
        durationMs: Date.now() - startedAt
      });

      this.cacheStatus(provider);
      return this.fallbackDecision(context, intent, provider);
    }
  }

  async getStatus(): Promise<ProviderInfo> {
    return this.getLoginStatus(false);
  }

  async composeOnAirNarration(params: {
    context: ContextBundle;
    decision: Decision;
    nowPlaying: Track | null;
    nowPlayingContext: TrackNarrationContext | null;
    queuedTracks: Track[];
  }): Promise<string | null> {
    if (params.decision.mode === "music-only") {
      return null;
    }

    if (!params.nowPlaying || this.config.codexMode !== "oauth-cli") {
      return null;
    }

    const loginStatus = await this.getLoginStatus(true);

    if (loginStatus.state !== "ready") {
      return null;
    }

    try {
      const output = await this.runCodexExec(
        this.buildNarrationPrompt({
          context: params.context,
          decision: params.decision,
          nowPlaying: params.nowPlaying,
          nowPlayingContext: params.nowPlayingContext,
          queuedTracks: params.queuedTracks
        }),
        this.config.codexNarrationSchemaPath
      );
      const parsed = narrationOutputSchema.parse(JSON.parse(output));
      const narration = parsed.narration.trim();
      if (narration.length === 0 || hasUnwantedNarrationStyle(narration)) {
        return null;
      }

      return narration;
    } catch {
      return null;
    }
  }

  private fallbackDecision(
    context: ContextBundle,
    intent: CodexIntent,
    provider: ProviderInfo
  ): Decision {
    const mood = intent.moodHint ?? inferMoodFromHour(context.currentTime);
    const nextEvent = context.calendar[0];
    const userAsked = context.userInput?.trim();
    const quietMode = intent.quietMode ?? false;
    const weatherSentence = context.weather.summary;
    const eventSentence = nextEvent
      ? `今天接下来最近的一件事是「${nextEvent.title}」。`
      : "今天的日程比较松，可以把节奏放得更均匀一点。";

    const say = userAsked
      ? quietMode
        ? "我把话收短一点，给你一段更安静的队列。"
        : `收到。结合你现在的状态，我先帮你把气氛调到更适合「${mood}」的轨道。`
      : `现在适合一段偏 ${mood} 的流速。${weatherSentence}${eventSentence}`;

    const query = pickPlaylistQuery(context.profile.playlists, mood);
    const secondQuery =
      context.weather.condition === "rain" ? "rain" : mood === "focus" ? "work" : "quiet";

    return {
      say,
      play: [
        {
          query,
          reason: `根据 ${mood} 时段和用户长期歌单选择起播曲目。`
        },
        {
          query: secondQuery,
          reason: "用第二首把当前氛围接稳。"
        }
      ],
      reason: [
        `source=${context.source}`,
        `mood=${mood}`,
        `weather=${context.weather.condition}`,
        `recentPlays=${context.recentPlays.length}`
      ].join(" | "),
      segue: quietMode ? "先让音乐把空间留出来。" : "先从这一首开始，把今天的节奏接上。",
      mood,
      mode: quietMode ? "music-only" : "narrated",
      provider
    };
  }

  private buildProvider(params: {
    kind: ProviderInfo["kind"];
    state: ProviderInfo["state"];
    authMode: ProviderInfo["authMode"];
    detail: string | null;
    durationMs: number | null;
  }): ProviderInfo {
    return {
      kind: params.kind,
      state: params.state,
      authMode: params.authMode,
      model: this.config.codexModel ?? "default",
      detail: params.detail,
      durationMs: params.durationMs
    };
  }

  private cacheStatus(value: ProviderInfo): void {
    this.statusCache = {
      expiresAt: Date.now() + 60_000,
      value
    };
  }

  private async getLoginStatus(forceRefresh: boolean): Promise<ProviderInfo> {
    if (!forceRefresh && this.statusCache && this.statusCache.expiresAt > Date.now()) {
      return this.statusCache.value;
    }

    if (this.config.codexMode !== "oauth-cli") {
      const disabled = this.buildProvider({
        kind: "fallback",
        state: "disabled",
        authMode: "none",
        detail: `CODEX_MODE=${this.config.codexMode}`,
        durationMs: 0
      });

      this.cacheStatus(disabled);
      return disabled;
    }

    try {
      const result = await this.runProcess(["login", "status"], {
        timeoutMs: 5_000,
        env: this.buildCodexEnv()
      });
      const output = [result.stdout, result.stderr].filter(Boolean).join("\n");
      const authMode = this.parseAuthMode(output);

      if (result.code === 0 && authMode !== "none") {
        const ready = this.buildProvider({
          kind: "codex-cli",
          state: "ready",
          authMode,
          detail: authMode === "chatgpt" ? "Authenticated via ChatGPT OAuth." : "Authenticated via API key.",
          durationMs: 0
        });

        this.cacheStatus(ready);
        return ready;
      }

      const fallback = this.buildProvider({
        kind: "fallback",
        state: "error",
        authMode,
        detail: compactLines(output) ?? "Run `codex login` to authenticate the local CLI.",
        durationMs: 0
      });

      this.cacheStatus(fallback);
      return fallback;
    } catch (error) {
      const failure = this.buildProvider({
        kind: "fallback",
        state: "error",
        authMode: "unknown",
        detail: `Unable to inspect Codex login status. ${clip(normalizeError(error), 180)}`,
        durationMs: 0
      });

      this.cacheStatus(failure);
      return failure;
    }
  }

  private parseAuthMode(output: string): ProviderInfo["authMode"] {
    if (/Logged in using ChatGPT/i.test(output)) {
      return "chatgpt";
    }

    if (/Logged in using API key/i.test(output)) {
      return "api-key";
    }

    if (/not logged in|logged out/i.test(output)) {
      return "none";
    }

    return "unknown";
  }

  private async runCodexExec(prompt: string, outputSchemaPath: string): Promise<string> {
    const runtimeHome = await mkdtemp(join(this.config.dataDir, "codex-home-"));
    const outputPath = resolve(runtimeHome, "last-message.json");

    try {
      await this.copyIfPresent(resolve(this.config.codexHomeDir, "auth.json"), resolve(runtimeHome, "auth.json"));
      await this.copyIfPresent(
        resolve(this.config.codexHomeDir, "installation_id"),
        resolve(runtimeHome, "installation_id")
      );

      const args = [
        "exec",
        "--ignore-user-config",
        "--ignore-rules",
        "--ephemeral",
        "-s",
        "read-only",
        "--skip-git-repo-check",
        "-C",
        this.config.rootDir,
        "-c",
        'approval_policy="never"',
        "-c",
        'analytics.enabled=false',
        "-c",
        'features.apps=false',
        "-c",
        'web_search="disabled"',
        "-c",
        `model_reasoning_effort="${this.config.codexReasoningEffort}"`,
        "-c",
        'model_verbosity="low"',
        "--color",
        "never",
        "--output-schema",
        outputSchemaPath,
        "-o",
        outputPath,
        "-"
      ];

      if (this.config.codexModel) {
        args.splice(4, 0, "-m", this.config.codexModel);
      }

      const env = this.buildCodexEnv(runtimeHome);

      const result = await this.runProcess(args, {
        cwd: this.config.rootDir,
        env,
        stdin: prompt,
        timeoutMs: this.config.codexExecTimeoutMs
      });

      if (result.timedOut) {
        throw new Error(`Timed out after ${this.config.codexExecTimeoutMs}ms.`);
      }

      if (result.code !== 0) {
        throw new Error(
          compactLines(result.stderr) ??
            compactLines(result.stdout) ??
            `Codex exited with code ${String(result.code)}${result.signal ? ` (${result.signal})` : ""}.`
        );
      }

      const output = await readFile(outputPath, "utf8");
      return output.trim();
    } finally {
      await rm(runtimeHome, { recursive: true, force: true });
    }
  }

  private buildCodexEnv(runtimeHome?: string): NodeJS.ProcessEnv {
    const env: NodeJS.ProcessEnv = {
      ...process.env
    };

    if (runtimeHome) {
      env.CODEX_HOME = runtimeHome;
    }

    if (this.config.codexProxyUrl) {
      env.HTTP_PROXY = this.config.codexProxyUrl;
      env.HTTPS_PROXY = this.config.codexProxyUrl;
      env.ALL_PROXY = this.config.codexProxyUrl;
      env.http_proxy = this.config.codexProxyUrl;
      env.https_proxy = this.config.codexProxyUrl;
      env.all_proxy = this.config.codexProxyUrl;
      env.NO_PROXY = env.NO_PROXY ?? "127.0.0.1,localhost";
      env.no_proxy = env.no_proxy ?? "127.0.0.1,localhost";
    }

    return env;
  }

  private async copyIfPresent(sourcePath: string, targetPath: string): Promise<void> {
    try {
      await access(sourcePath, fsConstants.F_OK);
      await copyFile(sourcePath, targetPath);
    } catch {
      // The auth file may live in a keychain-backed store instead of a file.
    }
  }

  private buildPrompt(context: ContextBundle, intent: CodexIntent): string {
    const promptPayload = {
      currentTime: context.currentTime,
      source: context.source,
      userInput: context.userInput ?? null,
      intent: {
        moodHint: intent.moodHint ?? null,
        quietMode: intent.quietMode ?? false
      },
      systemPrompt: clip(context.systemPrompt, 1600),
      userProfile: {
        taste: clip(context.profile.taste, 1600),
        routines: clip(context.profile.routines, 1200),
        moodRules: clip(context.profile.moodRules, 1200),
        playlists: context.profile.playlists
      },
      weather: context.weather,
      calendar: context.calendar,
      recentMessages: context.recentMessages,
      recentPlays: context.recentPlays
    };

    return [
      "You are Indio's radio decision engine.",
      "Return only JSON that matches the provided schema.",
      "Do not use tools.",
      "Do not read or write files.",
      "Do not browse the web.",
      "Use only the context below.",
      "Write all user-facing text in natural Simplified Chinese.",
      "Prefer concise narration and Netease-friendly search queries.",
      "The `say` field is only the emotional angle for this turn, not the final full on-air song introduction.",
      "When quietMode is true, set mode to music-only and keep narration brief.",
      "",
      JSON.stringify(promptPayload, null, 2)
    ].join("\n");
  }

  private buildNarrationPrompt(params: {
    context: ContextBundle;
    decision: Decision;
    nowPlaying: Track;
    nowPlayingContext: TrackNarrationContext | null;
    queuedTracks: Track[];
  }): string {
    const { context, decision, nowPlaying, nowPlayingContext, queuedTracks } = params;
    const localTime = getChinaTimeParts(context.currentTime);
    const previousTrack = context.recentPlays.find((track) => !sameTrack(track, nowPlaying)) ?? null;
    const promptPayload = {
      currentTime: context.currentTime,
      localTime: {
        timezone: "Asia/Shanghai",
        clock: localTime.clock,
        weekday: localTime.weekday
      },
      radioFrame: inferRadioFrame(context.currentTime, decision.mood),
      userInput: context.userInput ?? null,
      personaGuidance: clip(context.systemPrompt, 1500),
      tasteHighlights: markdownHighlights(context.profile.taste, 5, 90),
      routineHighlights: markdownHighlights(context.profile.routines, 2, 80),
      moodRules: markdownHighlights(context.profile.moodRules, 4, 80),
      weather: context.weather.summary,
      decision: {
        say: decision.say,
        segue: decision.segue,
        mood: decision.mood,
        mode: decision.mode
      },
      nowPlaying: {
        title: nowPlaying.title,
        artist: nowPlaying.artist,
        album: nowPlaying.album,
        mood: nowPlaying.mood
      },
      nowPlayingContext: nowPlayingContext
        ? {
            aliases: nowPlayingContext.aliases,
            releaseYear: nowPlayingContext.releaseYear,
            language: nowPlayingContext.language,
            styles: nowPlayingContext.styles,
            tags: nowPlayingContext.tags,
            awards: nowPlayingContext.awards,
            scenes: nowPlayingContext.scenes,
            reviewSnippet: nowPlayingContext.reviewSnippet,
            lyricPreview: nowPlayingContext.lyricPreview,
            primaryArtist: nowPlayingContext.primaryArtist
          }
        : null,
      previousTrack: previousTrack
        ? {
            title: previousTrack.title,
            artist: previousTrack.artist
          }
        : null,
      nextTrack:
        queuedTracks[0]
          ? {
              title: queuedTracks[0].title,
              artist: queuedTracks[0].artist
            }
          : null
    };

    return [
      "You write the final spoken on-air narration for Indio, a personal radio host.",
      "Return only JSON that matches the provided schema.",
      "Write all user-facing text in natural Simplified Chinese.",
      "This is the actual spoken radio copy for the current song, not notes and not metadata.",
      "Make it feel like a real radio DJ: relaxed, conversational, musically aware, and present in the moment, not like an encyclopedia or a generated song card.",
      "Radio feel comes from four things: a precise time-of-day scene, a direct address to likely listeners, a concrete musical handoff, and a short spoken sentence that sounds good aloud.",
      "Use the radioFrame as tone guidance: morning-city is bright and useful; noon-easy is unhurried and nostalgic; late-night is low-volume and intimate; weekend-party is energetic; workday-focus is clean and unobtrusive.",
      "Most turns are song transitions, not full show openings. If previousTrack exists, you may briefly close what just played before introducing nowPlaying. If there is no previousTrack, you may give a compact welcome.",
      "You may mention the local clock or weather only when it makes the line feel live and useful; do not force it every time.",
      "Never invent an FM frequency, hotline number, listener name, station slogan, chart ranking, or audience message. Only mention listener requests when userInput actually contains one.",
      "The narration must revolve around the listening experience of this exact song: what it sounds like, what mood it opens, what image the lyric suggests, or why it fits the listener right now.",
      "Do not drift into generic healing copy before you have anchored the listener in this exact song.",
      "Within the first sentence, mention the song title, artist, or a concrete auditory trait of the song.",
      "Use at most one metadata fact, and only if it genuinely makes the spoken transition better. Prefer audible details, mood, and the user's moment over catalog facts.",
      "Do not mention BPM, lyricists, composers, arrangers, producers, or credits unless the user explicitly asks for that kind of information.",
      "Turn any fact you use into a feeling or listening cue; never list facts mechanically.",
      "Use the user's request and profile to make it feel personal, but keep the song as the center of gravity at all times.",
      "Preferred transition structure: one natural line about the moment or previous song, one line that brings in nowPlaying, then a short handoff back to the music.",
      "For opening-like turns, use a compact version of real radio openings: greeting, time or listener scene, current mood, then the song. Do not make it longer than needed.",
      "For listener-request turns, acknowledge the request in one sentence, keep private details minimal, then let the song carry the message.",
      "Use spoken DJ phrases sparingly, such as '早上好', '午后这会儿', '夜深了', '刚才这首', '接下来我们听到的是', '一起听'. Vary them and do not make every paragraph start the same way.",
      "Write one short paragraph of 2 to 4 sentences, or 1 to 2 sentences if the turn should be quieter.",
      "Avoid canned intros, slogans, bullet-like structure, mechanical phrasing, data-card phrasing, and self-help monologues.",
      "Do not sound like an encyclopedia, album review, product copy, or inspirational social media post.",
      "Do not mention models, providers, APIs, playlists, fallback, queues, or technical system state.",
      "Do not output stage directions, bracketed cues, section titles, or labels such as BGM, opening, ending, or narration.",
      "Do not invent facts about the song or artist beyond the metadata provided.",
      "If lyric preview is provided, use it only to infer theme or imagery; do not quote lyrics verbatim for more than 8 consecutive Chinese characters.",
      "Avoid empty fake-empathy phrases such as '先安静接住', '接住你的心事', '把情绪接住', or similar wording.",
      "Avoid abstract AI-sounding phrases such as '把空气拉得很松', '空气自动收拢', '同一条气流', '纹理更轻', '我们直接接上', or '我们直接把下一首接上'.",
      "For handoffs, prefer concrete spoken radio phrasing: '这首歌给你', '一起来听', '我们听听看', '下一首是...', or '把时间交给这首歌'.",
      "You may borrow the calm cadence of a late-night radio show, but keep the copy grounded in the current song rather than abstract comfort talk.",
      "Vary sentence openings. Do not repeatedly start with phrases like '现在这首' or '接下来这首'.",
      "You may hint gently at the next song only if it feels natural.",
      "",
      JSON.stringify(promptPayload, null, 2)
    ].join("\n");
  }

  private runProcess(
    args: string[],
    options: {
      cwd?: string;
      env?: NodeJS.ProcessEnv;
      stdin?: string;
      timeoutMs: number;
    }
  ): Promise<ProcessResult> {
    return new Promise((resolveProcess, rejectProcess) => {
      const child = spawn(this.config.codexCliCommand, args, {
        cwd: options.cwd,
        env: options.env,
        stdio: ["pipe", "pipe", "pipe"]
      });

      let stdout = "";
      let stderr = "";
      let timedOut = false;
      let settled = false;

      const timer = setTimeout(() => {
        timedOut = true;
        child.kill("SIGTERM");

        setTimeout(() => {
          if (!settled) {
            child.kill("SIGKILL");
          }
        }, 500).unref();
      }, options.timeoutMs);

      child.stdout.on("data", (chunk: Buffer | string) => {
        stdout = tail(stdout + chunk.toString(), 8_000);
      });

      child.stderr.on("data", (chunk: Buffer | string) => {
        stderr = tail(stderr + chunk.toString(), 12_000);
      });

      child.on("error", (error) => {
        settled = true;
        clearTimeout(timer);
        rejectProcess(error);
      });

      child.on("close", (code, signal) => {
        settled = true;
        clearTimeout(timer);
        resolveProcess({
          code,
          stdout,
          stderr,
          timedOut,
          signal
        });
      });

      if (options.stdin) {
        child.stdin.write(options.stdin);
      }

      child.stdin.end();
    });
  }
}
