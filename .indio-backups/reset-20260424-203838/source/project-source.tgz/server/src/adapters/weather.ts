import type { WeatherSnapshot } from "../types.js";

export class WeatherAdapter {
  async getSnapshot(now = new Date()): Promise<WeatherSnapshot> {
    const hour = now.getHours();

    if (hour < 8) {
      return {
        condition: "clear",
        temperatureC: 19,
        summary: "空气偏凉，适合轻一点地把早晨拉开。"
      };
    }

    if (hour < 18) {
      return {
        condition: "cloudy",
        temperatureC: 24,
        summary: "云层有点厚，适合用清爽编曲把注意力提起来。"
      };
    }

    return {
      condition: "rain",
      temperatureC: 21,
      summary: "晚间有一点湿意，适合温暖、流动感更强的声音。"
    };
  }
}

