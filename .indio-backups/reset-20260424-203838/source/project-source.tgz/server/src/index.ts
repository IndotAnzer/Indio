import { createReadStream } from "node:fs";
import { access } from "node:fs/promises";
import { dirname, extname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import cors from "@fastify/cors";
import websocket from "@fastify/websocket";
import { config as loadDotenv } from "dotenv";
import Fastify from "fastify";
import { z } from "zod";
import { loadConfig } from "./config.js";
import { IndioRuntime } from "./runtime.js";
import type { StreamEvent } from "./types.js";

const currentDir = dirname(fileURLToPath(import.meta.url));
loadDotenv({ path: resolve(currentDir, "../../.env"), override: true });

const config = loadConfig();
const app = Fastify({
  logger: true
});

type SocketLike = {
  readyState: number;
  send: (data: string) => void;
  on?: (event: string, listener: () => void) => void;
};

const clients = new Set<SocketLike>();

function publish(event: StreamEvent): void {
  const payload = JSON.stringify(event);
  for (const client of clients) {
    if (client && client.readyState === 1) {
      client.send(payload);
    }
  }
}

const runtime = new IndioRuntime(config, publish);

await app.register(cors, {
  origin: [config.pwaUrl, /localhost/, /127\.0\.0\.1/]
});

await app.register(websocket);

app.get("/health", async () => ({
  ok: true,
  mode: config.codexMode,
  codex: await runtime.getCodexStatus(),
  music: runtime.getMusicStatus(),
  tts: runtime.getTtsStatus()
}));

app.get("/api/now", async () => ({
  now: runtime.getNowState()
}));

app.get("/api/next", async () => ({
  next: runtime.getNextTrack()
}));

app.get("/api/taste", async () => runtime.getTasteSummary());

app.get("/api/plan/today", async () => ({
  plan: runtime.getTodayPlan()
}));

app.get("/api/music/bootstrap", async () => ({
  music: runtime.getMusicBootstrap()
}));

app.post("/api/music/login/qr", async () => ({
  session: await runtime.createMusicQrLogin()
}));

app.get("/api/music/login/qr/check", async (request) => {
  const query = z.object({
    key: z.string().min(1)
  });
  const { key } = query.parse(request.query);

  return {
    status: await runtime.checkMusicQrLogin(key),
    music: runtime.getMusicBootstrap()
  };
});

app.post("/api/music/logout", async () => {
  await runtime.logoutMusic();

  return {
    ok: true,
    music: runtime.getMusicBootstrap()
  };
});

app.post("/api/chat", async (request, reply) => {
  const schema = z.object({
    message: z.string().min(1)
  });
  const body = schema.parse(request.body);

  try {
    return await runtime.handleTurn({
      source: "manual",
      userInput: body.message
    });
  } catch (error) {
    request.log.warn({ err: error }, "chat turn was not ready");
    return reply.code(503).send({
      error: error instanceof Error ? error.message : "电台这轮还没准备好，请稍等再试。"
    });
  }
});

app.post("/api/radio/advance", async (request, reply) => {
  const schema = z.object({
    currentSegmentId: z.string().min(1).optional()
  });

  const body = schema.parse(request.body ?? {});

  try {
    return {
      nowState: await runtime.advancePreparedSegment(body.currentSegmentId)
    };
  } catch (error) {
    request.log.warn({ err: error }, "radio segment advance was not ready");
    return reply.code(503).send({
      error: error instanceof Error ? error.message : "下一段电台还没准备好，请稍等。"
    });
  }
});

app.get("/api/pulse", async (request, reply) => {
  try {
    return await runtime.handleTurn({
      source: "schedule"
    });
  } catch (error) {
    request.log.warn({ err: error }, "scheduled turn was not ready");
    return reply.code(503).send({
      error: error instanceof Error ? error.message : "电台这轮还没准备好，请稍后。"
    });
  }
});

app.get("/media/tts/:filename", async (request, reply) => {
  const params = z.object({
    filename: z.string().regex(/^[a-f0-9]{16}\.(mp3|wav|ogg|opus|aac|flac)$/)
  });
  const { filename } = params.parse(request.params);
  const filePath = resolve(config.cacheDir, filename);

  try {
    await access(filePath);
  } catch {
    return reply.code(404).send({
      error: "TTS file not found"
    });
  }

  const extension = extname(filename);
  const contentType =
    extension === ".wav"
      ? "audio/wav"
      : extension === ".ogg" || extension === ".opus"
        ? "audio/ogg"
        : extension === ".aac"
          ? "audio/aac"
          : extension === ".flac"
            ? "audio/flac"
            : "audio/mpeg";

  reply.header("Cache-Control", "public, max-age=31536000, immutable");
  reply.type(contentType);
  return reply.send(createReadStream(filePath));
});

app.get(
  "/stream",
  { websocket: true },
  (socket) => {
    const client = socket as SocketLike;
    if (!client) {
      return;
    }
    clients.add(client);

    const nowState = runtime.getNowState();
    if (nowState) {
      client.send(
        JSON.stringify({
          type: "state.update",
          payload: nowState
        } satisfies StreamEvent)
      );
    }

    client.send(
      JSON.stringify({
        type: "plan.update",
        payload: runtime.getTodayPlan()
      } satisfies StreamEvent)
    );

    client.on?.("close", () => {
      clients.delete(client);
    });
  }
);

app.addHook("onClose", async () => {
  await runtime.shutdown();
});

try {
  await runtime.bootstrap();
  await app.listen({
    host: config.host,
    port: config.port
  });
} catch (error) {
  app.log.error(error);
  process.exit(1);
}
