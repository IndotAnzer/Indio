import { startTransition, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";

declare global {
  interface Window {
    webkitAudioContext?: typeof AudioContext;
    WeixinJSBridge?: {
      invoke: (
        name: string,
        data?: Record<string, unknown>,
        callback?: (() => void) | ((response: unknown) => void)
      ) => void;
    };
  }
}

type Track = {
  id: string;
  neteaseId: string | null;
  title: string;
  artist: string;
  album: string;
  mood: string;
  durationSec: number;
  streamUrl: string | null;
  artworkUrl: string | null;
  platformUrl: string | null;
  playbackSource: "netease" | "fallback";
};

type ProviderInfo = {
  kind: "codex-cli" | "fallback" | "local-control";
  state: "ready" | "fallback" | "error" | "disabled";
  authMode: "chatgpt" | "api-key" | "none" | "unknown";
  model: string | null;
  detail: string | null;
  durationMs: number | null;
};

type MusicBootstrap = {
  configured: boolean;
  provider: "netease-api-enhanced" | "fallback";
  baseUrl: string | null;
  cookieConfigured: boolean;
  unblockEnabled: boolean;
  loggedIn: boolean;
  user: NeteaseUserSummary | null;
  playlists: NeteasePlaylistSummary[];
  libraryTrackCount: number;
  loginSession: MusicQrSession | null;
  detail: string | null;
};

type NeteaseUserSummary = {
  uid: string;
  nickname: string;
  avatarUrl: string | null;
};

type NeteasePlaylistSummary = {
  id: string;
  name: string;
  trackCount: number;
  coverImgUrl: string | null;
  creatorName: string | null;
  ownedByUser: boolean;
};

type MusicQrSession = {
  key: string;
  qrUrl: string;
  qrImage: string | null;
  createdAt: string;
};

type MusicQrStatus = {
  code: number;
  authorized: boolean;
  state: "waiting" | "scanned" | "confirmed" | "expired" | "error";
  message: string;
};

type PreparedSegment = {
  segmentId: string;
  source: "manual" | "schedule" | "system";
  mood: string;
  mode: "narrated" | "music-only";
  provider: ProviderInfo;
  narrationText: string;
  narrationAudioUrl: string | null;
  segue: string;
  reason: string;
  outputDevice: string;
  nowPlaying: Track | null;
  queuedTracks: Track[];
  preparedAt: string;
};

type NowState = {
  segmentId: string;
  updatedAt: string;
  source: "manual" | "schedule" | "system";
  mood: string;
  mode: "narrated" | "music-only";
  provider: ProviderInfo;
  narrationText: string;
  narrationAudioUrl: string | null;
  segue: string;
  reason: string;
  outputDevice: string;
  nowPlaying: Track | null;
  queuedTracks: Track[];
  preparedNext: PreparedSegment | null;
};

type MusicBootstrapResponse = {
  music: MusicBootstrap;
};

type MusicQrCreateResponse = {
  session: MusicQrSession;
};

type MusicQrCheckResponse = {
  status: MusicQrStatus;
  music: MusicBootstrap;
};

type MusicLogoutResponse = {
  ok: boolean;
  music: MusicBootstrap;
};

type ChatResponse = {
  nowState: NowState;
};

type AdvanceResponse = {
  nowState: NowState;
};

type StreamEvent =
  | {
      type: "state.update";
      payload: NowState;
    }
  | {
      type: "plan.update";
      payload: unknown;
    };

const API_BASE = import.meta.env.VITE_INDIO_API_URL ?? "http://localhost:8787";
const SILENT_AUDIO_DATA_URL =
  "data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQIAAAAAAA==";

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);

  if (init?.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers
  });

  if (!response.ok) {
    try {
      const payload = (await response.json()) as { error?: string };
      if (payload?.error) {
        throw new Error(payload.error);
      }
    } catch (error) {
      if (error instanceof Error && error.message) {
        throw error;
      }
    }

    throw new Error(`Request failed: ${response.status}`);
  }

  return (await response.json()) as T;
}

function stopAudio(audio: HTMLAudioElement | null): void {
  if (!audio) {
    return;
  }

  audio.pause();
  audio.currentTime = 0;
  audio.onended = null;
  audio.onerror = null;
  audio.removeAttribute("src");
  audio.load();
}

function resolveMediaUrl(url: string): string {
  try {
    const apiBase = new URL(API_BASE);
    const mediaUrl = new URL(url, API_BASE);
    return new URL(`${mediaUrl.pathname}${mediaUrl.search}${mediaUrl.hash}`, apiBase.origin).toString();
  } catch {
    return url;
  }
}

function durationLabel(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const rest = String(seconds % 60).padStart(2, "0");
  return `${mins}:${rest}`;
}

function timeLabel(value: string): string {
  return new Intl.DateTimeFormat("zh-CN", {
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function playbackErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof DOMException && error.name === "NotAllowedError") {
    return "当前浏览器拦住了音频输出，点“播放”后再试一次。";
  }

  if (error instanceof Error && error.message) {
    return error.message;
  }

  return fallback;
}

function createPlaybackAbortError(): DOMException {
  return new DOMException("Playback was superseded.", "AbortError");
}

function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === "AbortError";
}

function playAudioElement(audio: HTMLAudioElement | null, url: string, signal?: AbortSignal): Promise<void> {
  if (!audio) {
    return Promise.resolve();
  }

  if (signal?.aborted) {
    return Promise.reject(createPlaybackAbortError());
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    const clear = () => {
      audio.onended = null;
      audio.onerror = null;
      signal?.removeEventListener("abort", handleAbort);
    };
    const resolveOnce = () => {
      if (settled) {
        return;
      }

      settled = true;
      clear();
      resolve();
    };
    const rejectOnce = (error: unknown) => {
      if (settled) {
        return;
      }

      settled = true;
      clear();
      reject(error);
    };
    const handleAbort = () => {
      stopAudio(audio);
      rejectOnce(createPlaybackAbortError());
    };

    signal?.addEventListener("abort", handleAbort, { once: true });
    audio.src = url;
    audio.load();
    audio.onended = () => {
      resolveOnce();
    };
    audio.onerror = () => {
      rejectOnce(new Error("Audio playback failed."));
    };

    audio.play().catch((error) => {
      rejectOnce(error);
    });
  });
}

async function playNarrationAudio(audio: HTMLAudioElement | null, url: string, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) {
    throw createPlaybackAbortError();
  }

  const response = await fetch(resolveMediaUrl(url), { signal });

  if (!response.ok) {
    throw new Error(`播报音频请求失败（${response.status}）`);
  }

  const blob = await response.blob();

  if (signal?.aborted) {
    throw createPlaybackAbortError();
  }

  const objectUrl = URL.createObjectURL(blob);

  try {
    await playAudioElement(audio, objectUrl, signal);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function createUnlockAudioContext(): AudioContext | null {
  const AudioContextCtor = window.AudioContext ?? window.webkitAudioContext;

  if (!AudioContextCtor) {
    return null;
  }

  try {
    return new AudioContextCtor();
  } catch {
    return null;
  }
}

async function warmAudioElement(audio: HTMLAudioElement): Promise<boolean> {
  try {
    audio.setAttribute("playsinline", "");
    audio.setAttribute("webkit-playsinline", "true");
    audio.preload = "auto";
    audio.muted = true;
    audio.src = SILENT_AUDIO_DATA_URL;
    await audio.play();
    audio.pause();
    audio.currentTime = 0;
    audio.removeAttribute("src");
    audio.load();
    audio.muted = false;
    return true;
  } catch {
    audio.pause();
    audio.currentTime = 0;
    audio.removeAttribute("src");
    audio.load();
    audio.muted = false;
    return false;
  }
}

function withTimeout<T>(task: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(new Error("timeout"));
    }, ms);

    task.then(
      (value) => {
        window.clearTimeout(timer);
        resolve(value);
      },
      (error: unknown) => {
        window.clearTimeout(timer);
        reject(error);
      }
    );
  });
}

function buildNarrationChars(text: string, progress: number, isPlaying: boolean): Array<{
  char: string;
  state: "idle" | "read" | "active" | "space" | "break";
}> {
  const chars = Array.from(text);
  const speakableCount = chars.reduce((count, char) => count + (/\s/.test(char) ? 0 : 1), 0);
  const spokenCount =
    speakableCount === 0 ? 0 : Math.min(speakableCount, Math.floor(progress * speakableCount));
  let cursor = 0;

  return chars.map((char) => {
    if (char === "\n") {
      return { char, state: "break" };
    }

    if (/\s/.test(char)) {
      return { char, state: "space" };
    }

    const currentIndex = cursor;
    cursor += 1;

    if (spokenCount >= speakableCount) {
      return { char, state: "read" };
    }

    if (currentIndex < spokenCount) {
      return { char, state: "read" };
    }

    if (isPlaying && currentIndex === spokenCount) {
      return { char, state: "active" };
    }

    return { char, state: "idle" };
  });
}

function materializePreparedSegment(segment: PreparedSegment): NowState {
  return {
    segmentId: segment.segmentId,
    updatedAt: segment.preparedAt,
    source: segment.source,
    mood: segment.mood,
    mode: segment.mode,
    provider: segment.provider,
    narrationText: segment.narrationText,
    narrationAudioUrl: segment.narrationAudioUrl,
    segue: segment.segue,
    reason: segment.reason,
    outputDevice: segment.outputDevice,
    nowPlaying: segment.nowPlaying,
    queuedTracks: segment.queuedTracks,
    preparedNext: null
  };
}

export default function App() {
  const [bootstrap, setBootstrap] = useState<MusicBootstrap | null>(null);
  const [nowState, setNowState] = useState<NowState | null>(null);
  const [qrSession, setQrSession] = useState<MusicQrSession | null>(null);
  const [qrStatusMessage, setQrStatusMessage] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [musicError, setMusicError] = useState<string | null>(null);
  const [audioReady, setAudioReady] = useState(false);
  const [isUnlockingAudio, setIsUnlockingAudio] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isStartingMusicLogin, setIsStartingMusicLogin] = useState(false);
  const [isLoggingOutMusic, setIsLoggingOutMusic] = useState(false);
  const [narrationProgress, setNarrationProgress] = useState(0);
  const [isNarrationPlaying, setIsNarrationPlaying] = useState(false);
  const [isPlaybackPlaying, setIsPlaybackPlaying] = useState(false);
  const [isPlaybackPaused, setIsPlaybackPaused] = useState(false);
  const [clockText, setClockText] = useState(() =>
    new Intl.DateTimeFormat("zh-CN", {
      hour: "2-digit",
      minute: "2-digit"
    }).format(new Date())
  );

  const narrationAudioRef = useRef<HTMLAudioElement | null>(null);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);
  const preloadMusicAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioReadyRef = useRef(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const unlockPromiseRef = useRef<Promise<boolean> | null>(null);
  const currentNowStateRef = useRef<NowState | null>(null);
  const playbackPhaseRef = useRef<"idle" | "narration" | "music">("idle");
  const lastSpokenSegmentId = useRef<string | null>(null);
  const lastPlaybackKey = useRef<string | null>(null);
  const advancingSegmentRef = useRef<string | null>(null);
  const skipPlaybackCleanupForSegmentRef = useRef<string | null>(null);
  const playbackRunId = useRef(0);
  const playbackAbortControllerRef = useRef<AbortController | null>(null);
  const qrPollingTimer = useRef<number | null>(null);

  function syncMusicBootstrap(music: MusicBootstrap): void {
    setBootstrap(music);
    setQrSession((current) => {
      if (music.loggedIn) {
        return null;
      }

      return music.loginSession ?? current;
    });
  }

  async function refreshMusicBootstrap(): Promise<MusicBootstrap> {
    const bootstrapResponse = await requestJson<MusicBootstrapResponse>("/api/music/bootstrap");

    startTransition(() => {
      syncMusicBootstrap(bootstrapResponse.music);
      if (bootstrapResponse.music.loggedIn) {
        setQrStatusMessage("网易云已连接，电台会优先从你的歌单里选歌。");
      }
    });

    return bootstrapResponse.music;
  }

  useEffect(() => {
    const timer = window.setInterval(() => {
      setClockText(
        new Intl.DateTimeFormat("zh-CN", {
          hour: "2-digit",
          minute: "2-digit"
        }).format(new Date())
      );
    }, 30_000);

    return () => {
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    void Promise.all([
      requestJson<MusicBootstrapResponse>("/api/music/bootstrap"),
      requestJson<{ now: NowState | null }>("/api/now")
    ])
      .then(([bootstrapResponse, nowResponse]) => {
        startTransition(() => {
          syncMusicBootstrap(bootstrapResponse.music);
          setNowState(nowResponse.now);
        });
      })
      .catch((fetchError: unknown) => {
        setError(fetchError instanceof Error ? fetchError.message : "电台初始化失败");
      });
  }, []);

  useEffect(() => {
    currentNowStateRef.current = nowState;
  }, [nowState]);

  useEffect(() => {
    let cancelled = false;
    let reconnectTimer: number | null = null;
    let socket: WebSocket | null = null;

    const connect = () => {
      if (cancelled) {
        return;
      }

      socket = new WebSocket(API_BASE.replace("http", "ws") + "/stream");

      socket.addEventListener("message", (event) => {
        const payload = JSON.parse(event.data) as StreamEvent;

        if (payload.type !== "state.update") {
          return;
        }

        startTransition(() => {
          setNowState(payload.payload);
          setError((current) => (current === "实时连接暂时不可用" ? null : current));
        });
      });

      socket.addEventListener("error", () => {
        setError("实时连接暂时不可用");
        socket?.close();
      });

      socket.addEventListener("close", () => {
        if (cancelled) {
          return;
        }

        setError("实时连接暂时不可用");
        reconnectTimer = window.setTimeout(connect, 2000);
      });
    };

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimer !== null) {
        window.clearTimeout(reconnectTimer);
      }
      socket?.close();
    };
  }, []);

  useEffect(() => {
    if (!qrSession?.key || bootstrap?.loggedIn) {
      if (qrPollingTimer.current !== null) {
        window.clearTimeout(qrPollingTimer.current);
        qrPollingTimer.current = null;
      }
      return;
    }

    let cancelled = false;

    const poll = async () => {
      try {
        const response = await requestJson<MusicQrCheckResponse>(
          `/api/music/login/qr/check?key=${encodeURIComponent(qrSession.key)}`
        );

        if (cancelled) {
          return;
        }

        startTransition(() => {
          syncMusicBootstrap(response.music);
          setQrStatusMessage(
            response.status.authorized || response.music.loggedIn
              ? "网易云已连接，电台会优先从你的歌单里选歌。"
              : response.status.state === "expired"
                ? "二维码已过期，请重新生成。"
                : response.status.message
          );
        });

        if (response.status.authorized || response.music.loggedIn || response.status.state === "expired") {
          return;
        }
      } catch (pollError: unknown) {
        if (!cancelled) {
          setQrStatusMessage(pollError instanceof Error ? pollError.message : "网易云登录状态检查失败");
        }
      }

      if (!cancelled) {
        qrPollingTimer.current = window.setTimeout(poll, 2000);
      }
    };

    void poll();

    return () => {
      cancelled = true;
      if (qrPollingTimer.current !== null) {
        window.clearTimeout(qrPollingTimer.current);
        qrPollingTimer.current = null;
      }
    };
  }, [qrSession?.key, bootstrap?.loggedIn]);

  useEffect(() => {
    if (audioReadyRef.current) {
      return;
    }

    const prime = () => {
      if (audioReadyRef.current) {
        return;
      }

      void unlockAudioPlayback();
    };

    window.addEventListener("pointerdown", prime, { passive: true });
    window.addEventListener("touchstart", prime, { passive: true });
    window.addEventListener("keydown", prime);

    return () => {
      window.removeEventListener("pointerdown", prime);
      window.removeEventListener("touchstart", prime);
      window.removeEventListener("keydown", prime);
    };
  }, []);

  useEffect(() => {
    const bridgeUnlock = () => {
      void unlockAudioPlayback();
    };

    document.addEventListener("WeixinJSBridgeReady", bridgeUnlock as EventListener, false);

    if (window.WeixinJSBridge) {
      try {
        window.WeixinJSBridge.invoke("getNetworkType", {}, bridgeUnlock);
      } catch {
        // Ignore bridge errors and fall back to direct user gestures.
      }
    }

    return () => {
      document.removeEventListener("WeixinJSBridgeReady", bridgeUnlock as EventListener, false);
    };
  }, []);

  useEffect(() => {
    const preparedNext = nowState?.preparedNext;

    if (!preparedNext) {
      if (preloadMusicAudioRef.current) {
        preloadMusicAudioRef.current.removeAttribute("src");
        preloadMusicAudioRef.current.load();
      }
      return;
    }

    if (preparedNext.narrationAudioUrl) {
      void fetch(resolveMediaUrl(preparedNext.narrationAudioUrl)).catch(() => {
        // Ignore prefetch failures; playback will still attempt on demand.
      });
    }

    if (preparedNext.nowPlaying?.streamUrl && preloadMusicAudioRef.current) {
      preloadMusicAudioRef.current.src = preparedNext.nowPlaying.streamUrl;
      preloadMusicAudioRef.current.preload = "auto";
      preloadMusicAudioRef.current.load();
    }
  }, [nowState?.preparedNext]);

  useEffect(() => {
    const audio = narrationAudioRef.current;

    if (!audio) {
      return;
    }

    let rafId: number | null = null;

    const pushProgress = () => {
      const isNarrationPhase = playbackPhaseRef.current === "narration";
      const hasActivePlayback = playbackPhaseRef.current !== "idle";
      const hasSource = Boolean(audio.currentSrc || audio.src);
      const playbackPlaying = hasActivePlayback && !audio.paused && !audio.ended;
      const playbackPaused = hasActivePlayback && hasSource && audio.paused && !audio.ended;

      if (isNarrationPhase) {
        const duration = Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : 0;
        const progress = duration > 0 ? Math.min(1, audio.currentTime / duration) : 0;
        setNarrationProgress(progress);
      }

      setIsNarrationPlaying(isNarrationPhase && !audio.paused && !audio.ended);
      setIsPlaybackPlaying(playbackPlaying);
      setIsPlaybackPaused(playbackPaused);

      if (!audio.paused && !audio.ended) {
        rafId = window.requestAnimationFrame(pushProgress);
      }
    };

    const start = () => {
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
      }
      pushProgress();
    };

    const stop = () => {
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
        rafId = null;
      }

      if (playbackPhaseRef.current === "narration") {
        const duration = Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : 0;
        setNarrationProgress(audio.ended && duration > 0 ? 1 : duration > 0 ? Math.min(1, audio.currentTime / duration) : 0);
      }

      setIsNarrationPlaying(playbackPhaseRef.current === "narration" && !audio.paused && !audio.ended);
      setIsPlaybackPlaying(false);
      setIsPlaybackPaused(playbackPhaseRef.current !== "idle" && Boolean(audio.currentSrc || audio.src) && !audio.ended);
    };

    const reset = () => {
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
        rafId = null;
      }
      playbackPhaseRef.current = "idle";
      setNarrationProgress(0);
      setIsNarrationPlaying(false);
      setIsPlaybackPlaying(false);
      setIsPlaybackPaused(false);
    };

    audio.addEventListener("play", start);
    audio.addEventListener("pause", stop);
    audio.addEventListener("ended", stop);
    audio.addEventListener("loadedmetadata", pushProgress);
    audio.addEventListener("emptied", reset);
    audio.addEventListener("error", reset);

    return () => {
      if (rafId !== null) {
        window.cancelAnimationFrame(rafId);
      }
      audio.removeEventListener("play", start);
      audio.removeEventListener("pause", stop);
      audio.removeEventListener("ended", stop);
      audio.removeEventListener("loadedmetadata", pushProgress);
      audio.removeEventListener("emptied", reset);
      audio.removeEventListener("error", reset);
    };
  }, []);

  useEffect(() => {
    setNarrationProgress(0);
    setIsNarrationPlaying(false);
    setIsPlaybackPaused(false);
  }, [nowState?.updatedAt]);

  async function unlockAudioPlayback(): Promise<boolean> {
    if (audioReadyRef.current) {
      return true;
    }

    if (unlockPromiseRef.current) {
      return unlockPromiseRef.current;
    }

    const audio = narrationAudioRef.current;

    if (!audio) {
      return false;
    }

    const unlockAttempt = (async () => {
      setIsUnlockingAudio(true);
      try {
        if (!audioContextRef.current) {
          audioContextRef.current = createUnlockAudioContext();
        }

        let unlocked = false;

        if (audioContextRef.current) {
          try {
            if (audioContextRef.current.state !== "running") {
              await withTimeout(audioContextRef.current.resume(), 500);
            }

            const buffer = audioContextRef.current.createBuffer(1, 1, 22050);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = buffer;
            source.connect(audioContextRef.current.destination);
            source.start(0);
            unlocked = audioContextRef.current.state === "running";
          } catch {
            unlocked = false;
          }
        }

        const warmed = await withTimeout(warmAudioElement(audio), 1000).catch(() => false);
        unlocked = unlocked || warmed;

        audioReadyRef.current = unlocked;
        setAudioReady(unlocked);

        if (unlocked) {
          setMusicError(null);
          return true;
        }

        setMusicError("这个内嵌浏览器还没放行音频，再点一次“播放”试试。");
        return false;
      } finally {
        setIsUnlockingAudio(false);
        unlockPromiseRef.current = null;
      }
    })();

    unlockPromiseRef.current = unlockAttempt;
    return unlockAttempt;
  }

  async function playNowState(
    state: NowState,
    options?: { requireUnlock?: boolean; skipNarration?: boolean }
  ): Promise<void> {
    if (!state.nowPlaying) {
      return;
    }

    if (options?.requireUnlock) {
      const unlocked = await unlockAudioPlayback();
      if (!unlocked) {
        return;
      }
    } else if (!audioReadyRef.current) {
      setMusicError("点“播放”开始播放。");
      return;
    }

    playbackRunId.current += 1;
    const runId = playbackRunId.current;
    playbackAbortControllerRef.current?.abort();
    const abortController = new AbortController();
    playbackAbortControllerRef.current = abortController;
    playbackRunId.current = runId;
    const outputAudio = narrationAudioRef.current;
    const isCurrentPlayback = () =>
      playbackRunId.current === runId &&
      playbackAbortControllerRef.current === abortController &&
      !abortController.signal.aborted;

    playbackPhaseRef.current = "idle";
    setIsPlaybackPlaying(false);
    setIsPlaybackPaused(false);
    stopAudio(outputAudio);
    stopAudio(musicAudioRef.current);

    if (state.mode === "narrated" && !options?.skipNarration && lastSpokenSegmentId.current !== state.segmentId) {
      if (state.narrationAudioUrl) {
        try {
          if (!isCurrentPlayback()) {
            return;
          }

          playbackPhaseRef.current = "narration";
          setNarrationProgress(0);
          setIsNarrationPlaying(true);
          setIsPlaybackPlaying(true);
          setIsPlaybackPaused(false);
          await playNarrationAudio(outputAudio, state.narrationAudioUrl, abortController.signal);

          if (!isCurrentPlayback()) {
            return;
          }

          lastSpokenSegmentId.current = state.segmentId;
          setNarrationProgress(1);
          setIsNarrationPlaying(false);
        } catch (playError: unknown) {
          if (isAbortError(playError) || !isCurrentPlayback()) {
            return;
          }

          playbackPhaseRef.current = "idle";
          setIsNarrationPlaying(false);
          setIsPlaybackPlaying(false);
          setIsPlaybackPaused(false);
          setMusicError(playbackErrorMessage(playError, "播报音频加载失败，当前只显示字幕。"));
        }
      } else {
        lastSpokenSegmentId.current = state.segmentId;
      }
    }

    if (!isCurrentPlayback() || !state.nowPlaying) {
      return;
    }

    if (state.nowPlaying.streamUrl) {
      setMusicError(null);

      try {
        playbackPhaseRef.current = "music";
        setIsPlaybackPlaying(true);
        setIsPlaybackPaused(false);
        await playAudioElement(outputAudio, state.nowPlaying.streamUrl, abortController.signal);

        if (!isCurrentPlayback()) {
          return;
        }

        const continued = await advanceOnceForSegment(state.segmentId);

        if (!continued) {
          playbackPhaseRef.current = "idle";
          if (playbackAbortControllerRef.current === abortController) {
            playbackAbortControllerRef.current = null;
          }
        }

        return;
      } catch (playError: unknown) {
        if (isAbortError(playError) || !isCurrentPlayback()) {
          return;
        }

        playbackPhaseRef.current = "idle";
        setIsPlaybackPlaying(false);
        setIsPlaybackPaused(false);
        setMusicError(playError instanceof Error ? playError.message : "音乐播放失败");
      }
    }

    if (state.nowPlaying.platformUrl) {
      setIsPlaybackPlaying(false);
      setIsPlaybackPaused(false);
      setMusicError("当前曲目没有直连音频，已经保留网易云跳转链接。");
    } else {
      setIsPlaybackPlaying(false);
      setIsPlaybackPaused(false);
      setMusicError("当前队列没有可直接播放的音频链接。");
    }
  }

  function publishNowStateUpdate(nextState: NowState): void {
    currentNowStateRef.current = nextState;
    startTransition(() => {
      setNowState(nextState);
      setMusicError(null);
    });
  }

  function publishAutoContinuation(nextState: NowState, finishedSegmentId: string): void {
    skipPlaybackCleanupForSegmentRef.current = finishedSegmentId;
    lastPlaybackKey.current = nextState.segmentId;
    publishNowStateUpdate(nextState);
  }

  async function requestAdvancedState(finishedSegmentId: string): Promise<NowState> {
    const response = await requestJson<AdvanceResponse>("/api/radio/advance", {
      method: "POST",
      body: JSON.stringify({
        currentSegmentId: finishedSegmentId
      })
    });

    return response.nowState;
  }

  async function syncAdvancedStateWithServer(finishedSegmentId: string, expectedSegmentId: string): Promise<void> {
    try {
      const syncedState = await requestAdvancedState(finishedSegmentId);

      if (syncedState.segmentId !== expectedSegmentId) {
        return;
      }

      publishNowStateUpdate({
        ...syncedState,
        updatedAt: currentNowStateRef.current?.updatedAt ?? syncedState.updatedAt
      });
    } catch (advanceError: unknown) {
      setMusicError(advanceError instanceof Error ? advanceError.message : "下一段电台还没准备好。");
    }
  }

  async function advanceOnceForSegment(finishedSegmentId: string): Promise<boolean> {
    if (advancingSegmentRef.current === finishedSegmentId) {
      return true;
    }

    advancingSegmentRef.current = finishedSegmentId;
    const current = currentNowStateRef.current;

    if (!current || current.segmentId !== finishedSegmentId) {
      advancingSegmentRef.current = null;
      return false;
    }

    if (current.preparedNext) {
      const promoted = materializePreparedSegment(current.preparedNext);
      publishAutoContinuation(promoted, finishedSegmentId);
      void syncAdvancedStateWithServer(finishedSegmentId, promoted.segmentId);
      void playNowState(promoted);
      return true;
    }

    try {
      const advancedState = await requestAdvancedState(finishedSegmentId);

      if (advancedState.segmentId === finishedSegmentId) {
        advancingSegmentRef.current = null;
        return false;
      }

      publishAutoContinuation(advancedState, finishedSegmentId);
      void playNowState(advancedState);
      return true;
    } catch (advanceError: unknown) {
      advancingSegmentRef.current = null;
      setMusicError(advanceError instanceof Error ? advanceError.message : "下一段电台还没准备好。");
      return false;
    }
  }

  useEffect(() => {
    if (!nowState?.nowPlaying) {
      return;
    }

    const playbackKey = nowState.segmentId;

    if (lastPlaybackKey.current === playbackKey) {
      return;
    }

    lastPlaybackKey.current = playbackKey;
    void playNowState(nowState);

    return () => {
      if (skipPlaybackCleanupForSegmentRef.current === playbackKey) {
        skipPlaybackCleanupForSegmentRef.current = null;
        return;
      }

      playbackRunId.current += 1;
      playbackAbortControllerRef.current?.abort();
      playbackAbortControllerRef.current = null;
      playbackPhaseRef.current = "idle";
      stopAudio(narrationAudioRef.current);
      stopAudio(musicAudioRef.current);
    };
  }, [nowState]);

  useEffect(() => {
    const stationAudio = narrationAudioRef.current;

    if (!stationAudio) {
      return;
    }

    const handleEnded = () => {
      if (playbackPhaseRef.current !== "music") {
        return;
      }

      const finishedState = currentNowStateRef.current;

      if (!finishedState?.nowPlaying) {
        return;
      }

      void advanceOnceForSegment(finishedState.segmentId);
    };

    stationAudio.addEventListener("ended", handleEnded);

    return () => {
      stationAudio.removeEventListener("ended", handleEnded);
    };
  }, []);

  function pauseCurrentPlayback(): void {
    const audio = narrationAudioRef.current;

    if (!audio || audio.paused || audio.ended) {
      return;
    }

    audio.pause();
    setIsPlaybackPlaying(false);
    setIsPlaybackPaused(Boolean(audio.currentSrc || audio.src));
  }

  async function resumeCurrentPlayback(): Promise<void> {
    const audio = narrationAudioRef.current;

    if (!audio || playbackPhaseRef.current === "idle" || audio.ended || !Boolean(audio.currentSrc || audio.src)) {
      if (nowState) {
        await playNowState(nowState, { requireUnlock: true });
      }
      return;
    }

    const unlocked = await unlockAudioPlayback();

    if (!unlocked) {
      return;
    }

    try {
      setIsPlaybackPlaying(true);
      setIsPlaybackPaused(false);
      await audio.play();
      setMusicError(null);
    } catch (resumeError: unknown) {
      setIsPlaybackPlaying(false);
      setIsPlaybackPaused(true);
      setMusicError(playbackErrorMessage(resumeError, "播放恢复失败。"));
    }
  }

  async function handlePlayPause(): Promise<void> {
    if (!nowState?.nowPlaying) {
      return;
    }

    const audio = narrationAudioRef.current;
    const hasActiveAudio = Boolean(audio?.currentSrc || audio?.src);

    if (audio && hasActiveAudio && !audio.paused && !audio.ended) {
      pauseCurrentPlayback();
      return;
    }

    if (audio && hasActiveAudio && audio.paused && !audio.ended && playbackPhaseRef.current !== "idle") {
      await resumeCurrentPlayback();
      return;
    }

    await playNowState(nowState, { requireUnlock: true });
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    const message = draft.trim();

    if (!message) {
      return;
    }

    setIsSending(true);
    setError(null);

    try {
      await unlockAudioPlayback();

      const response = await requestJson<ChatResponse>("/api/chat", {
        method: "POST",
        body: JSON.stringify({ message })
      });

      startTransition(() => {
        setNowState(response.nowState);
        setDraft("");
      });
    } catch (submitError: unknown) {
      setError(submitError instanceof Error ? submitError.message : "电台生成失败");
    } finally {
      setIsSending(false);
    }
  }

  async function handleStartMusicLogin(): Promise<void> {
    setIsStartingMusicLogin(true);
    setQrStatusMessage(null);

    try {
      const response = await requestJson<MusicQrCreateResponse>("/api/music/login/qr", {
        method: "POST"
      });

      startTransition(() => {
        setQrSession(response.session);
        setQrStatusMessage("请用网易云音乐 App 扫码并确认登录。");
      });

      await refreshMusicBootstrap();
    } catch (loginError: unknown) {
      setQrStatusMessage(loginError instanceof Error ? loginError.message : "网易云二维码生成失败");
    } finally {
      setIsStartingMusicLogin(false);
    }
  }

  async function handleLogoutMusic(): Promise<void> {
    setIsLoggingOutMusic(true);
    setQrStatusMessage(null);

    try {
      const response = await requestJson<MusicLogoutResponse>("/api/music/logout", {
        method: "POST"
      });

      startTransition(() => {
        syncMusicBootstrap(response.music);
        setQrStatusMessage("已断开网易云。");
      });
    } catch (logoutError: unknown) {
      setQrStatusMessage(logoutError instanceof Error ? logoutError.message : "网易云退出登录失败");
    } finally {
      setIsLoggingOutMusic(false);
    }
  }

  const queue = nowState?.queuedTracks.slice(0, 3) ?? [];
  const currentTrack = nowState?.nowPlaying ?? null;
  const backgroundImage = currentTrack?.artworkUrl ? `url(${currentTrack.artworkUrl})` : null;
  const narrationChars = buildNarrationChars(nowState?.narrationText ?? "", narrationProgress, isNarrationPlaying);
  const playbackControlLabel = isUnlockingAudio ? "准备中..." : isPlaybackPlaying ? "暂停" : "播放";

  return (
    <div className="radio-shell">
      <audio ref={narrationAudioRef} hidden playsInline preload="auto" />
      <audio ref={musicAudioRef} hidden playsInline preload="none" />
      <audio ref={preloadMusicAudioRef} hidden playsInline preload="auto" />

      <div className="radio-glow radio-glow-left" />
      <div className="radio-glow radio-glow-right" />

      <main
        className="radio-frame"
        onPointerDownCapture={() => {
          if (!audioReadyRef.current) {
            void unlockAudioPlayback();
          }
        }}
      >
        <section className="radio-stage">
          <div
            className="radio-backdrop"
            style={backgroundImage ? { backgroundImage } : undefined}
          />
          <div className="radio-backdrop-mask" />

          <header className="station-bar">
            <div>
              <p className="station-kicker">Indio Radio</p>
              <strong className="station-title">
                {bootstrap?.loggedIn
                  ? `${bootstrap.user?.nickname ?? "你的"}深夜电台`
                  : "Personal Late Night FM"}
              </strong>
            </div>
            <div className="station-pills">
              <span>{audioReady ? "Audio Ready" : "Tap Play"}</span>
              <span>{clockText}</span>
            </div>
          </header>

          <section className="on-air">
            <div className="record-meta">
              <span className={`live-pill ${currentTrack ? "is-live" : ""}`}>
                {currentTrack ? "ON AIR" : "STANDBY"}
              </span>
              <h1>{currentTrack?.title ?? "等待开播"}</h1>
              <p className="track-line">
                {currentTrack
                  ? `${currentTrack.artist} · ${currentTrack.album}`
                  : "发一句话，电台就会开始生成歌曲和口播。"}
              </p>
            </div>

            <div className="narration-card">
              <p className="narration-label">{isNarrationPlaying ? "正在口播" : "当前口播"}</p>
              {nowState?.narrationText ? (
                <div className="karaoke-line" aria-label={nowState.narrationText}>
                  {narrationChars.map((item, index) => {
                    if (item.state === "break") {
                      return <br key={`break-${index}`} />;
                    }

                    if (item.state === "space") {
                      return (
                        <span className="karaoke-char is-space" key={`space-${index}`}>
                          {" "}
                        </span>
                      );
                    }

                    return (
                      <span
                        className={[
                          "karaoke-char",
                          item.state === "read" ? "is-read" : "",
                          item.state === "active" ? "is-active" : ""
                        ]
                          .filter(Boolean)
                          .join(" ")}
                        key={`${item.char}-${index}`}
                      >
                        {item.char}
                      </span>
                    );
                  })}
                </div>
              ) : (
                <p className="narration-placeholder">
                  {currentTrack ? "这一轮没有生成妥当的口播，电台先把音乐接进来。" : "等你发第一句，电台会先准备好口播，再把歌接进来。"}
                </p>
              )}
            </div>

            <div className="radio-controls">
              <button
                className="primary-button"
                aria-label={playbackControlLabel}
                aria-pressed={isPlaybackPlaying}
                disabled={!currentTrack || isUnlockingAudio}
                onClick={() => {
                  void handlePlayPause();
                }}
                type="button"
              >
                {playbackControlLabel}
              </button>
              <button
                className="ghost-button"
                disabled={!currentTrack}
                onClick={() => {
                  if (nowState) {
                    lastSpokenSegmentId.current = null;
                    void playNowState(nowState, { requireUnlock: true, skipNarration: false });
                  }
                }}
                type="button"
              >
                重播口播
              </button>
              <button
                className="ghost-button"
                disabled={!currentTrack}
                onClick={() => {
                  if (nowState) {
                    void playNowState(nowState, { requireUnlock: true, skipNarration: true });
                  }
                }}
                type="button"
              >
                只播歌曲
              </button>
            </div>

            {currentTrack ? (
              <div className="track-meta-bar">
                <span>{durationLabel(currentTrack.durationSec)}</span>
                <span>{timeLabel(nowState?.updatedAt ?? new Date().toISOString())}</span>
                <span>{currentTrack.playbackSource === "netease" ? "网易云直连" : "本地占位曲库"}</span>
                {currentTrack.platformUrl ? (
                  <a href={currentTrack.platformUrl} rel="noreferrer" target="_blank">
                    打开网易云
                  </a>
                ) : null}
              </div>
            ) : null}

            {musicError ? <p className="radio-message is-warning">{musicError}</p> : null}
            {error ? <p className="radio-message is-warning">{error}</p> : null}
          </section>

          <footer className="radio-footer">
            <section className="coming-up">
              <div className="footer-head">
                <p className="station-kicker">Coming Up</p>
                <span>{queue.length} 首待播</span>
              </div>
              <div className="coming-list">
                {queue.length > 0 ? (
                  queue.map((track, index) => (
                    <div className="coming-item" key={track.neteaseId ?? track.id}>
                      <span className="coming-index">{String(index + 1).padStart(2, "0")}</span>
                      <div>
                        <strong>{track.title}</strong>
                        <p>
                          {track.artist} · {durationLabel(track.durationSec)}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="coming-empty">下一首还没排好，先让这一首慢慢往下走。</p>
                )}
              </div>
            </section>

            <section className="radio-console">
              <div className="footer-head">
                <p className="station-kicker">Call In</p>
                <span>{bootstrap?.loggedIn ? "已连接网易云" : "未连接网易云"}</span>
              </div>

              <form className="radio-composer" onSubmit={handleSubmit}>
                <textarea
                  onChange={(event) => setDraft(event.target.value)}
                  placeholder="例如：给我一段适合写代码的专注流 / 下一首 / 安静一点"
                  rows={3}
                  value={draft}
                />
                <div className="composer-actions">
                  <button className="primary-button" disabled={isSending} type="submit">
                    {isSending ? "整套电台生成中..." : "发送给电台"}
                  </button>
                  {bootstrap?.loggedIn ? (
                    <button
                      className="ghost-button"
                      disabled={isLoggingOutMusic}
                      onClick={() => {
                        void handleLogoutMusic();
                      }}
                      type="button"
                    >
                      {isLoggingOutMusic ? "断开中..." : "断开网易云"}
                    </button>
                  ) : (
                    <button
                      className="secondary-button"
                      disabled={isStartingMusicLogin}
                      onClick={() => {
                        void handleStartMusicLogin();
                      }}
                      type="button"
                    >
                      {isStartingMusicLogin ? "生成二维码..." : "连接网易云"}
                    </button>
                  )}
                </div>
              </form>

              {bootstrap?.loggedIn ? (
                <p className="radio-message">
                  当前已连接 {bootstrap.user?.nickname ?? "网易云"}，电台会优先从你的歌单里挑歌。
                </p>
              ) : (
                <div className="login-drawer">
                  <p className="radio-message">
                    想让电台只围绕你的歌单运转，先连接网易云。
                  </p>
                  {qrSession?.qrImage ? (
                    <img
                      alt="网易云登录二维码"
                      className="qr-image"
                      src={qrSession.qrImage}
                    />
                  ) : null}
                  {qrStatusMessage ? <p className="radio-message">{qrStatusMessage}</p> : null}
                </div>
              )}
            </section>
          </footer>
        </section>
      </main>
    </div>
  );
}
